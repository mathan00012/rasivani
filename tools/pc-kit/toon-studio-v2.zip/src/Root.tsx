import React from 'react';
import {Composition} from 'remotion';
import {RahuKalam} from './RahuKalam';
import {Episode, Story} from './Episode';
import {Thumb} from './Thumb';
import {Showreel} from './Showreel';
import timing from './timing.json';

const emptyStory: Story = {slug: 'empty', lang: 'ta', format: 'short', fps: 30, total: 60, lines: [], scenes: [{name: 'studio', from: 0, cast: [{who: 'VANI', x: 540}]}], dir: ''};

export const Root: React.FC = () => (
  <>
    <Composition id="RahuKalamTa" component={RahuKalam} durationInFrames={timing.total} fps={timing.fps} width={1080} height={1920} />
    <Composition id="Episode" component={Episode as any} durationInFrames={60} fps={30} width={1080} height={1920} defaultProps={emptyStory as any}
      calculateMetadata={({props}: any) => ({durationInFrames: props.total, fps: props.fps,
        width: props.format === 'long' ? 1920 : 1080, height: props.format === 'long' ? 1080 : 1920})} />
    <Composition id="Thumb" component={Thumb as any} durationInFrames={1} fps={30} width={1280} height={720}
      defaultProps={{variant: 0, text: '*உங்க* ராகு காலம் எப்போ?', scene: 'village', local: 'THATHA', format: 'long'} as any}
      calculateMetadata={({props}: any) => (props.format === 'short' ? {width: 1080, height: 1920} : {width: 1280, height: 720})} />
    <Composition id="Showreel" component={Showreel} durationInFrames={600} fps={30} width={1920} height={1080} />
  </>
);
