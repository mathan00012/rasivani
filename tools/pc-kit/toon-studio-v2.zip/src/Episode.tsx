// Generic episode player: renders any story made by tools/make.mjs (props = story json).
// Auto-direction: camera follows the speaker, punch-ins on "!" and "?!", wide shots for info cards,
// gestures from emotion, listeners react, portal between scenes, captions, hook, outro.
import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, Easing, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Vani, Local, INK, POSE, Arm, Expr, LocalKind} from './Toon';
import {Background} from './Scenes';

export type Line = {id: string; who: string; expr?: Expr; pose?: string; react?: Expr; scene: string; text: string; start: number; frames: number; amp: number[];
  card?: {title: string; rows: string[]}; audio?: string};
export type Story = {slug: string; lang: string; format: 'short' | 'long'; fps: number; total: number; look?: any; hook?: string; cta?: string; url?: string;
  lines: Line[]; scenes: {name: string; from: number; cast: {who: string; x: number}[]}[]; dir: string};

export const fontCss = (s: (p: string) => string) => `
@font-face { font-family: BalooTa; src: url(${s('fonts/baloo-ta.woff2')}); }
@font-face { font-family: BalooTa; src: url(${s('fonts/baloo-la.woff2')}); unicode-range: U+0000-00FF; }
@font-face { font-family: BalooTa; src: url(${s('fonts/baloo-te.woff2')}); unicode-range: U+0C00-0C7F; }`;

const ease = Easing.out(Easing.back(1.4));
const GESTURE: Record<string, string[]> = {
  happy: ['wave', 'cheer', 'point'], shock: ['stop', 'cheer'], smirk: ['point', 'hip'], stern: ['stop', 'point'], angry: ['point', 'stop'],
  confused: ['shrug', 'think'], think: ['think'], sheepish: ['facepalm', 'hip'], sad: ['rest'], neutral: ['point', 'shrug', 'wave'],
};
const LEFT_HOLD: Record<string, Arm> = {THATHA: POSE.fan, PAATI: POSE.hip, KUTTI: POSE.hip, RAJA: POSE.hip, VENDOR: POSE.hip, PANDIT: POSE.fan};

const lineAt = (lines: Line[], f: number) => {
  let cur: Line | null = null, idx = -1;
  lines.forEach((l, i) => { if (f >= l.start - 4) { cur = l; idx = i; } });
  return {cur: cur as Line | null, idx};
};

// smooth value that eases from the previous target to the new one at each line change
function follow<T extends Record<string, number>>(f: number, keys: [number, T][], dur = 7): T {
  let v = keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [k, nv] = keys[i];
    if (f < k) break;
    const p = interpolate(f, [k, k + dur], [0, 1], {extrapolateRight: 'clamp', easing: ease});
    const o: any = {}; for (const key in nv) o[key] = (v as any)[key] + (nv[key] - (v as any)[key]) * p; v = o;
  }
  return v;
}

const Captions: React.FC<{lines: Line[]; frame: number; long: boolean}> = ({lines, frame, long}) => {
  for (const l of lines) {
    const i = frame - l.start;
    if (i < 0 || i >= l.frames + 6) continue;
    const words = l.text.split(/\s+/).filter(Boolean);
    const per = long ? 4 : 2;
    const chunks: string[] = [];
    for (let k = 0; k < words.length; k += per) chunks.push(words.slice(k, k + per).join(' '));
    const total = chunks.reduce((a, c) => a + c.length, 0) || 1;
    let acc = 0, idx = 0, startOf = 0;
    for (let k = 0; k < chunks.length; k++) { const st = (acc / total) * l.frames; if (i >= st) { idx = k; startOf = st; } acc += chunks[k].length; }
    const pop = interpolate(i - startOf, [0, 4], [0.7, 1], {extrapolateRight: 'clamp', easing: Easing.out(Easing.back(3))});
    const color = l.who === 'VANI' ? '#FFE14D' : '#FFFFFF';
    return (
      <div style={{position: 'absolute', left: 50, right: 50, top: long ? 860 : 1470, textAlign: 'center', transform: `scale(${pop})`}}>
        <span style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: long ? 76 : 92, lineHeight: 1.15, color, WebkitTextStroke: `14px ${INK}`, paintOrder: 'stroke fill', textShadow: '0 8px 0 rgba(0,0,0,.35)'}}>
          {chunks[idx]}
        </span>
      </div>
    );
  }
  return null;
};

const Card: React.FC<{card: {title: string; rows: string[]}; at: number; frame: number; long: boolean}> = ({card, at, frame, long}) => {
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - at, fps, config: {damping: 11}});
  return (
    <div style={{position: 'absolute', left: long ? 1080 : 80, right: long ? 80 : 80, top: long ? 120 : 260, transform: `scale(${s}) rotate(${(1 - s) * -6}deg)`,
      background: '#FFF8E7', border: `8px solid ${INK}`, borderRadius: 40, padding: '30px 36px', boxShadow: '0 14px 0 rgba(0,0,0,.25)'}}>
      <div style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 62, color: '#FF1E3C', lineHeight: 1.1, marginBottom: 10}}>{card.title}</div>
      {card.rows.map((r, i) => {
        const rs = spring({frame: frame - at - 8 - i * 7, fps, config: {damping: 12}});
        return <div key={i} style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 48, color: INK, lineHeight: 1.25, opacity: rs, transform: `translateX(${(1 - rs) * 60}px)`}}>
          <span style={{color: '#0FA3A3'}}>● </span>{r}</div>;
      })}
    </div>
  );
};

export const Episode: React.FC<Story> = (story) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const long = width > height;
  const {lines, scenes} = story;

  // current scene
  let si = 0; scenes.forEach((s, i) => { if (frame >= s.from) si = i; });
  const scene = scenes[si];
  const nextScene = scenes[si + 1];
  const {cur, idx} = lineAt(lines, frame);
  const talkOf = (who: string) => {
    for (const l of lines) { const i = frame - l.start; if (l.who === who && i >= 0 && i < l.frames) return l.amp[i] || 0; }
    return 0;
  };
  const posOf = (who: string) => scene.cast.find((c) => c.who === who)?.x ?? 780;
  const vaniX = posOf('VANI');

  // ── camera keys: one per line in this scene ──
  const sceneLines = lines.filter((l) => l.start >= scene.from && (!nextScene || l.start < nextScene.from));
  const camKeys: [number, {x: number; y: number; z: number}][] = [[scene.from, {x: 540, y: long ? 1120 : 1180, z: long ? 1 : 1.28}]];
  sceneLines.forEach((l, k) => {
    const loud = /[!！]\s*$|\?!/.test(l.text);
    const wide = !!l.card || (k > 0 && k % 4 === 3);
    const sx = posOf(l.who);
    camKeys.push([l.start - 3, wide ? {x: 540, y: long ? 1120 : 1180, z: long ? 1 : 1.28}
      : {x: long ? 540 + (sx - 540) * 0.45 : sx, y: long ? 1080 : 1010, z: long ? (loud ? 1.45 : 1.2) : loud ? 1.7 : 1.45}]);
  });
  const cam = follow(frame, camKeys, 7);
  const loudNow = cur && /[!！]\s*$|\?!/.test(cur.text) && frame - cur.start < 8 && frame >= cur.start;
  const shake = loudNow ? Math.sin(frame * 3) * 9 : 0;
  const base = long ? height / 1150 : 1;

  // ── acting ──
  const actFor = (who: string, isVani: boolean) => {
    const keys: [number, {t: number; b: number; lt: number; lb: number}][] = [];
    const hold = isVani ? POSE.mic : POSE.rest;
    const leftHold = isVani ? POSE.rest : (LEFT_HOLD[who] || POSE.rest);
    keys.push([0, {t: hold.t, b: hold.b, lt: leftHold.t, lb: leftHold.b}]);
    let expr: Expr = 'neutral';
    lines.forEach((l, k) => {
      if (l.who === who) {
        const options = l.pose ? [l.pose] : GESTURE[l.expr || 'neutral'] || ['rest'];
        const g = POSE[options[k % options.length]] || POSE.rest;
        // VANI: right hand keeps the mic, left hand gestures. Locals: right hand gestures.
        if (isVani) keys.push([l.start, {t: POSE.mic.t, b: POSE.mic.b, lt: g.t, lb: g.b}]);
        else keys.push([l.start, {t: g.t, b: g.b, lt: leftHold.t, lb: leftHold.b}]);
        keys.push([l.start + Math.max(20, l.frames - 6), isVani ? {t: POSE.mic.t, b: POSE.mic.b, lt: POSE.rest.t, lb: POSE.rest.b} : {t: POSE.rest.t, b: POSE.rest.b, lt: leftHold.t, lb: leftHold.b}]);
      }
    });
    const a = follow(frame, keys.sort((x, y) => x[0] - y[0]), 6);
    // expression: own line expr while talking, else react to the current line
    if (cur) expr = cur.who === who ? (cur.expr || 'neutral') : (cur.react || (isVani ? 'neutral' : 'neutral'));
    return {armR: {t: a.t, b: a.b}, armL: {t: a.lt, b: a.lb}, expr};
  };

  // portal/wipe progress around each scene change
  const toNext = nextScene ? nextScene.from - frame : 999;
  const fromPrev = frame - scene.from;
  const pr = si > 0 && fromPrev < 12 ? interpolate(fromPrev, [0, 12], [1600, 0], {easing: Easing.inOut(Easing.cubic)})
    : toNext <= 12 ? interpolate(12 - toNext, [0, 12], [0, 1600], {easing: Easing.inOut(Easing.cubic)}) : 0;
  const walkIn = interpolate(fromPrev, [0, 18], [1, 0], {extrapolateRight: 'clamp'});

  const outroAt = story.total - Math.round(fps * 1.6);
  const outroS = spring({frame: frame - outroAt, fps, config: {damping: 10}});
  const hookS = spring({frame: frame - 2, fps, config: {damping: 8}});
  const cardLine = cur && cur.card && frame >= cur.start - 4 && frame < cur.start + cur.frames + 10 ? cur : null;

  return (
    <AbsoluteFill style={{backgroundColor: '#120C33'}}>
      <style>{fontCss(staticFile)}</style>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        <g transform={`translate(${width / 2 + shake} ${height / 2}) scale(${base * cam.z}) translate(${-cam.x} ${-cam.y})`}>
          <Background name={scene.name} frame={frame} />
          {scene.cast.slice().sort((a, b) => (a.who === 'VANI' ? 1 : 0) - (b.who === 'VANI' ? 1 : 0)).map((c) => {
            const isVani = c.who === 'VANI';
            const act = actFor(c.who, isVani);
            const speaking = cur && cur.who === c.who;
            const target = cur && !speaking ? posOf(cur.who) : null;
            const lookX = speaking && isVani ? 0 : target !== null ? Math.sign(target - c.x) : isVani ? -1 : 1;
            const x = isVani ? c.x + walkIn * 700 : c.x;
            const t = talkOf(c.who);
            return (
              <g key={c.who} transform={`translate(${x} ${isVani ? 1620 : 1600}) scale(0.95)`}>
                {isVani
                  ? <Vani frame={frame} talk={t} expr={act.expr} armR={act.armR} armL={act.armL} lookX={lookX} prop="mic" look={story.look || 'classic'} walk={walkIn > 0.02 ? 1 : 0}
                      sweat={act.expr === 'sheepish'} tilt={act.expr === 'confused' ? -8 : 0} />
                  : <Local kind={c.who as LocalKind} frame={frame} talk={t} expr={act.expr} armR={act.armR} armL={{...act.armL, b: act.armL.b + (c.who === 'THATHA' ? Math.sin(frame / 3) * 10 : 0)}} lookX={lookX}
                      tilt={act.expr === 'confused' ? 8 : 0} />}
              </g>
            );
          })}
        </g>
        {pr > 0 && <g transform={`translate(${width / 2} ${height / 2}) rotate(${frame * 12})`}>
          {[1, 0.8, 0.6, 0.4, 0.2].map((k, i) => <circle key={i} r={pr * k} fill={i % 2 ? '#00E5FF' : '#FF1E3C'} stroke={INK} strokeWidth={10} />)}
          {[...Array(8)].map((_, i) => <path key={i} d={`M0 0 Q${pr * 0.3} ${-pr * 0.1} ${pr * 0.5} ${pr * 0.2}`} stroke="#FFE14D" strokeWidth={16} fill="none" transform={`rotate(${i * 45})`} />)}
        </g>}
      </svg>

      {story.hook && frame < (lines[0]?.start ?? 0) + (lines[0]?.frames ?? 60) && (
        <div style={{position: 'absolute', top: long ? 60 : 150, width: '100%', textAlign: 'center', transform: `scale(${hookS}) rotate(${Math.sin(frame / 3) * 2}deg)`}}>
          <span style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: long ? 120 : 130, color: '#FF1E3C', WebkitTextStroke: `16px #FFF8E7`, paintOrder: 'stroke fill'}}>{story.hook}</span>
        </div>
      )}
      {cardLine && <Card card={cardLine.card!} at={cardLine.start} frame={frame} long={long} />}
      <Captions lines={lines} frame={frame} long={long} />
      {frame >= outroAt && <div style={{position: 'absolute', left: long ? 460 : 70, right: long ? 460 : 70, top: long ? 200 : 300, padding: '36px 20px', borderRadius: 40,
        background: '#FFF8E7', border: `8px solid ${INK}`, textAlign: 'center', transform: `scale(${outroS})`}}>
        <div style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 60, color: INK, lineHeight: 1.2}}>{story.cta || ''}</div>
        <div style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 78, color: '#FF1E3C'}}>rasivani.com</div>
      </div>}
      <div style={{position: 'absolute', top: 36, right: 40, fontFamily: 'BalooTa', fontWeight: 800, fontSize: 40, color: '#fff', opacity: 0.85, WebkitTextStroke: `6px ${INK}`, paintOrder: 'stroke fill'}}>RasiVani</div>

      {lines.map((l) => <Sequence key={l.id} from={l.start}><Audio src={staticFile(l.audio!)} /></Sequence>)}
      {scenes.slice(1).map((s, i) => <Sequence key={'w' + i} from={Math.max(0, s.from - 12)}><Audio src={staticFile('whoosh.wav')} volume={0.7} /></Sequence>)}
      {lines.filter((l) => l.card).map((l) => <Sequence key={'d' + l.id} from={l.start + 6}><Audio src={staticFile('ding.wav')} volume={0.8} /></Sequence>)}
      {lines.filter((l) => /[!！]\s*$|\?!/.test(l.text)).map((l) => <Sequence key={'p' + l.id} from={l.start}><Audio src={staticFile('pop.wav')} volume={0.5} /></Sequence>)}
      <Sequence from={outroAt}><Audio src={staticFile('ding.wav')} /></Sequence>
    </AbsoluteFill>
  );
};
