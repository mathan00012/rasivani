// RasiVani cartoon cast: code-drawn SVG characters (no images, no GPU).
// Every character is drawn with feet at (0,0); place with <g transform="translate(x,y) scale(s)">.
import React from 'react';

export const INK = '#2B1B17';
export type Arm = {t: number; b: number}; // t = upper-arm angle from straight down (outward +), b = elbow bend
export type Expr = 'neutral' | 'happy' | 'shock' | 'smirk' | 'sheepish' | 'stern' | 'confused' | 'angry' | 'sad' | 'think';
export type Look = 'classic' | 'saree' | 'langavoni' | 'modern';
export type ToonProps = {
  frame: number; talk: number; // talk = mouth openness 0..1 from voice amplitude
  lookX?: number; lookY?: number; expr?: Expr;
  armL?: Arm; armR?: Arm; prop?: 'mic' | 'phone' | 'micphone' | 'fan' | null;
  phoneText?: boolean; sweat?: boolean; tilt?: number; walk?: number; look?: Look;
};

export const POSE: Record<string, Arm> = {
  rest: {t: 12, b: -8}, mic: {t: 30, b: -150}, wave: {t: 110, b: 20}, stop: {t: 78, b: 88},
  phone: {t: 22, b: -125}, phoneUp: {t: 60, b: -150}, point: {t: 92, b: -6}, hip: {t: 40, b: -120},
  fan: {t: 30, b: -140}, shrug: {t: 60, b: 70}, think: {t: 18, b: -165}, cheer: {t: 150, b: 15}, facepalm: {t: 28, b: -172},
};

const rad = (d: number) => (d * Math.PI) / 180;
const limb = (sx: number, sy: number, side: number, a: Arm, l1: number, l2: number) => {
  const ex = sx + side * Math.sin(rad(a.t)) * l1, ey = sy + Math.cos(rad(a.t)) * l1;
  const hx = ex + side * Math.sin(rad(a.t + a.b)) * l2, hy = ey + Math.cos(rad(a.t + a.b)) * l2;
  return {ex, ey, hx, hy};
};

const ArmShape: React.FC<{sx: number; sy: number; side: number; a: Arm; skin: string; sleeve?: string; l1?: number; l2?: number; w?: number; children?: React.ReactNode}> =
  ({sx, sy, side, a, skin, sleeve, l1 = 115, l2 = 105, w = 30, children}) => {
    const {ex, ey, hx, hy} = limb(sx, sy, side, a, l1, l2);
    const d = `M${sx} ${sy} L${ex} ${ey} L${hx} ${hy}`;
    return (
      <g>
        <path d={d} stroke={INK} strokeWidth={w + 12} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <path d={d} stroke={skin} strokeWidth={w} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        {sleeve && <path d={`M${sx} ${sy} L${sx + (ex - sx) * 0.55} ${sy + (ey - sy) * 0.55}`} stroke={sleeve} strokeWidth={w + 8} strokeLinecap="round" />}
        <circle cx={hx} cy={hy} r={w * 0.72} fill={skin} stroke={INK} strokeWidth={6} />
        <g transform={`translate(${hx},${hy})`}>{children}</g>
      </g>
    );
  };

const blinkOpen = (frame: number, seed: number) => {
  const p = (frame + seed) % 97;
  return p < 2 ? 0.1 : p < 4 ? 0.45 : 1;
};

const Eyes: React.FC<{cx: number; cy: number; gap: number; rx: number; ry: number; open: number; lx: number; ly: number; expr: Expr; brow: string; browW: number; skin: string}> =
  ({cx, cy, gap, rx, ry, open, lx, ly, expr, brow, browW, skin}) => {
    const shock = expr === 'shock';
    const o = shock ? 1.15 : expr === 'smirk' ? Math.min(open, 0.55) : expr === 'angry' ? Math.min(open, 0.7) : expr === 'sad' ? Math.min(open, 0.65) : open;
    if (expr === 'think') { lx = 0.6; ly = -0.9; }
    const browY = cy - ry - 22 + (shock ? -16 : expr === 'stern' || expr === 'angry' ? 6 : 0);
    const eye = (side: number) => {
      const x = cx + side * gap;
      const tiltIn = expr === 'angry' ? 26 : expr === 'stern' ? 14 : expr === 'sad' ? -18 : expr === 'confused' ? (side < 0 ? -12 : 10) : expr === 'sheepish' ? -10 : expr === 'smirk' ? (side < 0 ? 4 : -10) : 0;
      return (
        <g key={side}>
          <ellipse cx={x} cy={cy} rx={rx} ry={ry * (shock ? 1.15 : 1)} fill="#fff" stroke={INK} strokeWidth={5} />
          <circle cx={x + lx * rx * 0.35} cy={cy + ly * ry * 0.3} r={rx * (shock ? 0.38 : 0.5)} fill={INK} />
          <circle cx={x + lx * rx * 0.35 + rx * 0.18} cy={cy + ly * ry * 0.3 - ry * 0.2} r={rx * 0.15} fill="#fff" />
          {o < 1 && (
            <path d={`M${x - rx - 4} ${cy - ry - 6} L${x + rx + 4} ${cy - ry - 6} L${x + rx + 4} ${cy - ry + 2 * ry * (1 - o)} Q${x} ${cy - ry + 2 * ry * (1 - o) + 8} ${x - rx - 4} ${cy - ry + 2 * ry * (1 - o)} Z`}
              fill={skin} stroke={INK} strokeWidth={4} />
          )}
          <path d={`M${x - rx} ${browY} Q${x} ${browY - 10} ${x + rx} ${browY}`}
            transform={`rotate(${-side * tiltIn * 0.6} ${x} ${browY})`}
            stroke={brow} strokeWidth={browW} fill="none" strokeLinecap="round" />
        </g>
      );
    };
    return <g>{eye(-1)}{eye(1)}</g>;
  };

const Mouth: React.FC<{x: number; y: number; talk: number; expr: Expr; w: number}> = ({x, y, talk, expr, w}) => {
  if (talk > 0.08) {
    const ry = 5 + talk * 26, rx = w * (0.75 + talk * 0.25);
    return (
      <g>
        <ellipse cx={x} cy={y + ry * 0.4} rx={rx} ry={ry} fill="#5A1414" stroke={INK} strokeWidth={5} />
        <ellipse cx={x} cy={y + ry * 0.9} rx={rx * 0.55} ry={ry * 0.4} fill="#E2606A" />
      </g>
    );
  }
  if (expr === 'shock') return <ellipse cx={x} cy={y + 10} rx={w * 0.5} ry={18} fill="#5A1414" stroke={INK} strokeWidth={5} />;
  if (expr === 'smirk') return <path d={`M${x - w} ${y + 4} Q${x} ${y + 10} ${x + w} ${y - 12}`} stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
  if (expr === 'sheepish') return <path d={`M${x - w} ${y + 6} Q${x - w / 2} ${y - 4} ${x} ${y + 6} Q${x + w / 2} ${y + 14} ${x + w} ${y + 2}`} stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
  if (expr === 'sad' || expr === 'angry') return <path d={`M${x - w * 0.8} ${y + 14} Q${x} ${y - 8} ${x + w * 0.8} ${y + 14}`} stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
  if (expr === 'stern' || expr === 'confused' || expr === 'think') return <path d={`M${x - w * 0.7} ${y + 6} L${x + w * 0.7} ${y + (expr === 'stern' ? 6 : -2)}`} stroke={INK} strokeWidth={7} strokeLinecap="round" />;
  return <path d={`M${x - w} ${y} Q${x} ${y + 26} ${x + w} ${y}`} stroke={INK} strokeWidth={7} fill={expr === 'happy' ? '#fff' : 'none'} strokeLinecap="round" />;
};

// Kaala-Mic: VANI's brass time-travel microphone with a clock face
export const KaalaMic: React.FC<{rot?: number}> = ({rot = 0}) => (
  <g transform={`rotate(${rot})`}>
    <rect x={-11} y={-20} width={22} height={95} rx={9} fill="#8A5A1C" stroke={INK} strokeWidth={5} />
    <circle cx={0} cy={-58} r={40} fill="#E8B23A" stroke={INK} strokeWidth={6} />
    <circle cx={0} cy={-58} r={27} fill="#FFF4D6" stroke={INK} strokeWidth={3} />
    {[...Array(12)].map((_, i) => <line key={i} x1={0} y1={-81} x2={0} y2={-76} stroke={INK} strokeWidth={3} transform={`rotate(${i * 30} 0 -58)`} />)}
    <line x1={0} y1={-58} x2={0} y2={-76} stroke="#FF1E3C" strokeWidth={4} strokeLinecap="round" />
    <line x1={0} y1={-58} x2={12} y2={-58} stroke={INK} strokeWidth={4} strokeLinecap="round" />
  </g>
);

export const Phone: React.FC<{text?: boolean; s?: number}> = ({text, s = 1}) => (
  <g transform={`scale(${s}) rotate(-8)`}>
    <rect x={-34} y={-70} width={68} height={120} rx={12} fill="#14161F" stroke={INK} strokeWidth={5} />
    <rect x={-27} y={-60} width={54} height={98} rx={6} fill={text ? '#FFF6E5' : '#3BD1E8'} />
    {text && <>
      <circle cx={0} cy={-36} r={12} fill="#FF1E3C" />
      <rect x={-20} y={-16} width={40} height={6} rx={3} fill={INK} />
      <rect x={-20} y={-4} width={30} height={6} rx={3} fill="#0FA3A3" />
      <rect x={-20} y={8} width={36} height={6} rx={3} fill={INK} />
    </>}
  </g>
);

// VANI's four looks
export const LOOKS: Record<Look, {label: string; top: string; band: string; trim: string; skirt?: string; legs: string; shoe: string; hair: 'bun' | 'braid' | 'pony'}> = {
  classic:   {label: 'Classic reporter (kurta)', top: '#0FA3A3', band: '#FF1E3C', trim: '#FFC93C', legs: '#F3EBDD', shoe: '#7A3B12', hair: 'bun'},
  saree:     {label: 'Festival silk saree', top: '#C2185B', band: '#F2B705', trim: '#F2B705', skirt: '#C2185B', legs: '#C2185B', shoe: '#7A3B12', hair: 'bun'},
  langavoni: {label: 'Langa voni (half saree)', top: '#2E9E4F', band: '#FF7A1A', trim: '#F2C230', skirt: '#6A2C91', legs: '#6A2C91', shoe: '#7A3B12', hair: 'braid'},
  modern:    {label: 'Modern explorer (jacket)', top: '#2F5DA8', band: '#FFFFFF', trim: '#FF1E3C', legs: '#23395D', shoe: '#FFFFFF', hair: 'pony'},
};

// ── VANI: RasiVani's time-travelling reporter ──
export const Vani: React.FC<ToonProps> = (p) => {
  const {frame, talk, lookX = 0, lookY = 0, expr = 'neutral', armL = POSE.rest, armR = POSE.rest, prop, phoneText, sweat, tilt = 0, walk = 0, look = 'classic'} = p;
  const L = LOOKS[look];
  const skin = '#B9774E';
  const step = walk ? Math.sin(frame / 3) * 26 * walk : 0;
  const breathe = Math.sin(frame / 14) * 3, bob = talk > 0.1 ? Math.sin(frame / 3) * 3 : walk ? -Math.abs(Math.sin(frame / 3)) * 10 : 0;
  const headTilt = tilt + (talk > 0.1 ? Math.sin(frame / 6) * 3 : 0);
  const open = blinkOpen(frame, 11);
  const long = !!L.skirt;
  return (
    <g>
      <ellipse cx={0} cy={4} rx={120} ry={18} fill="#000" opacity={0.18} />
      {!long && [-1, 1].map((s) => (
        <g key={s}>
          <path d={`M${s * 34} -215 L${s * 40 + s * step} -28`} stroke={INK} strokeWidth={42} strokeLinecap="round" />
          <path d={`M${s * 34} -215 L${s * 40 + s * step} -28`} stroke={L.legs} strokeWidth={30} strokeLinecap="round" />
          <ellipse cx={s * 52 + s * step} cy={-12} rx={34} ry={16} fill={L.shoe} stroke={INK} strokeWidth={5} />
        </g>
      ))}
      {long && <>
        {[-1, 1].map((s) => <ellipse key={s} cx={s * 50 + s * step * 0.5} cy={-10} rx={32} ry={15} fill={L.shoe} stroke={INK} strokeWidth={5} />)}
        <path d={`M-100 -230 L${-118 - step * 0.3} -22 Q0 -8 ${118 + step * 0.3} -22 L100 -230 Z`} fill={L.skirt} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <path d={`M${-118 - step * 0.3} -40 Q0 -26 ${118 + step * 0.3} -40`} stroke={L.trim} strokeWidth={16} fill="none" />
        {look === 'saree' && [-60, -20, 20, 60].map((x) => <path key={x} d={`M${x} -220 L${x * 1.2} -40`} stroke="#8E0F44" strokeWidth={4} />)}
      </>}
      <g transform={`translate(0 ${breathe + bob})`}>
        {L.hair === 'braid' && <g transform={`rotate(${Math.sin(frame / 10) * 3} 70 -640)`}>
          {[0, 1, 2, 3, 4, 5].map((i) => <ellipse key={i} cx={78 + i * 3} cy={-600 + i * 46} rx={26 - i * 2} ry={28} fill="#1B1212" stroke={INK} strokeWidth={4} />)}
          <circle cx={96} cy={-330} r={14} fill="#FF7A1A" stroke={INK} strokeWidth={3} />
        </g>}
        {/* top */}
        {look === 'modern' ? <>
          <path d="M-72 -462 Q0 -484 72 -462 L96 -230 Q0 -214 -96 -230 Z" fill="#FFFFFF" stroke={INK} strokeWidth={6} />
          <path d="M8 -400 l14 30 l32 4 l-24 22 l6 32 l-28 -16 l-28 16 l6 -32 l-24 -22 l32 -4 Z" fill="#FF1E3C" stroke={INK} strokeWidth={3} transform="translate(-8 40) scale(0.8)" />
          <path d="M-72 -462 L-100 -228 L-40 -232 L-30 -440 Z" fill={L.top} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M72 -462 L100 -228 L40 -232 L30 -440 Z" fill={L.top} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M-96 -230 Q0 -214 96 -230 L100 -205 Q0 -190 -100 -205 Z" fill={L.legs} stroke={INK} strokeWidth={5} />
        </> : look === 'classic' ? <>
          <path d="M-72 -462 Q0 -484 72 -462 L108 -212 Q0 -192 -108 -212 Z" fill={L.top} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M-40 -470 Q0 -440 40 -470" fill="none" stroke={INK} strokeWidth={5} />
          <path d="M-60 -462 L88 -260" stroke={L.band} strokeWidth={36} strokeLinecap="round" />
          <path d="M-60 -462 L88 -260" stroke={L.trim} strokeWidth={6} strokeDasharray="6 14" />
          <path d="M-108 -212 Q0 -192 108 -212" fill="none" stroke={L.trim} strokeWidth={8} />
        </> : <>
          {/* blouse + drape (saree pallu / voni) */}
          <path d="M-72 -462 Q0 -484 72 -462 L84 -330 Q0 -316 -84 -330 Z" fill={look === 'saree' ? '#F2B705' : L.top} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M-84 -330 Q0 -316 84 -330 L100 -228 Q0 -212 -100 -228 Z" fill={look === 'saree' ? L.top : skin} stroke={INK} strokeWidth={6} />
          <path d="M-78 -470 L-30 -470 L110 -240 L40 -226 Z" fill={L.band === '#F2B705' ? L.top : L.band} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M-30 -470 L110 -240" stroke={L.trim} strokeWidth={12} />
          <path d="M-40 -455 Q0 -420 40 -455" stroke="#F2C230" strokeWidth={10} fill="none" />
          <circle cx={0} cy={-418} r={10} fill="#F2C230" stroke={INK} strokeWidth={3} />
        </>}
        <rect x={-17} y={-512} width={34} height={56} fill={skin} stroke={INK} strokeWidth={5} />
        <g transform={`rotate(${headTilt} 0 -500)`}>
          {L.hair === 'bun' && <>
            <circle cx={98} cy={-712} r={46} fill="#1B1212" stroke={INK} strokeWidth={5} />
            {[...Array(7)].map((_, i) => <circle key={i} cx={98 + Math.cos(rad(200 + i * 22)) * 50} cy={-712 + Math.sin(rad(200 + i * 22)) * 50} r={9} fill="#fff" stroke={INK} strokeWidth={2} />)}
          </>}
          {L.hair === 'pony' && <g transform={`rotate(${Math.sin(frame / 6) * 8} 60 -720)`}>
            <path d="M60 -720 Q170 -700 150 -560 Q120 -640 70 -690 Z" fill="#1B1212" stroke={INK} strokeWidth={5} />
            <rect x={48} y={-738} width={26} height={22} rx={6} fill="#FF1E3C" stroke={INK} strokeWidth={3} transform="rotate(30 60 -727)" />
          </g>}
          {[-1, 1].map((s) => <g key={s}><circle cx={s * 114} cy={-606} r={19} fill={skin} stroke={INK} strokeWidth={5} /><circle cx={s * 116} cy={-578} r={9} fill="#F2C230" stroke={INK} strokeWidth={3} /></g>)}
          <circle cx={0} cy={-612} r={116} fill={skin} stroke={INK} strokeWidth={6} />
          <path d="M-120 -600 C-128 -770 128 -770 120 -600 C110 -660 70 -706 0 -700 C-40 -690 -60 -650 -120 -600 Z" fill="#1B1212" stroke={INK} strokeWidth={5} />
          {look === 'saree' && <path d="M-40 -716 Q0 -700 40 -716 L0 -690 Z" fill="#F2C230" stroke={INK} strokeWidth={3} />}
          {[-1, 1].map((s) => <ellipse key={s} cx={s * 72} cy={-566} rx={20} ry={11} fill="#F07C7C" opacity={0.45} />)}
          <Eyes cx={0} cy={-612} gap={44} rx={27} ry={33} open={open} lx={lookX} ly={lookY} expr={expr} brow="#1B1212" browW={8} skin={skin} />
          <circle cx={0} cy={-664} r={7} fill="#FF1E3C" />
          <path d="M-6 -588 Q0 -576 8 -586" stroke={INK} strokeWidth={5} fill="none" strokeLinecap="round" />
          <Mouth x={0} y={-552} talk={talk} expr={expr} w={26} />
          {sweat && <path d="M108 -680 Q122 -654 112 -640 Q98 -632 96 -650 Q96 -664 108 -680 Z" fill="#7FD6F2" stroke={INK} strokeWidth={4} />}
        </g>
        <ArmShape sx={-66} sy={-440} side={-1} a={armL} skin={skin} sleeve={look === 'saree' ? '#F2B705' : L.top}>
          {(prop === 'phone' || prop === 'micphone') && armL.b < -90 && armL.b > -160 && <g transform="translate(6,-40)"><Phone text={phoneText} s={1.3} /></g>}
        </ArmShape>
        <ArmShape sx={66} sy={-440} side={1} a={armR} skin={skin} sleeve={look === 'saree' ? '#F2B705' : L.top}>
          {(prop === 'mic' || prop === 'micphone') && <g transform="translate(0,10)"><KaalaMic rot={-10} /></g>}
        </ArmShape>
      </g>
    </g>
  );
};

// ── Locals: one flexible rig for the people VANI meets ──
export type LocalKind = 'THATHA' | 'PAATI' | 'KUTTI' | 'RAJA' | 'VENDOR' | 'PANDIT';
type LocalCfg = {skin: string; top: string; topKind: 'bare' | 'shirt' | 'robe' | 'saree'; bottom: string; trim: string; hair: 'bald' | 'bun' | 'spiky' | 'crown' | 'turban' | 'tuft';
  stache?: string; glasses?: boolean; vibhuti?: boolean; namam?: boolean; size: number; prop?: 'fan' | 'staff' | 'scroll' | 'ball' | null};
export const LOCALS: Record<LocalKind, LocalCfg> = {
  THATHA: {skin: '#7C4A2D', top: '#FFF4DC', topKind: 'bare', bottom: '#FFF4DC', trim: '#D4A017', hair: 'bald', stache: '#F4F1EA', vibhuti: true, size: 0.95, prop: 'fan'},
  PAATI:  {skin: '#8A5636', top: '#8E1B3A', topKind: 'saree', bottom: '#8E1B3A', trim: '#E2B33C', hair: 'bun', glasses: true, size: 0.85, prop: 'staff'},
  KUTTI:  {skin: '#A86A44', top: '#FFC93C', topKind: 'shirt', bottom: '#2F5DA8', trim: '#FF1E3C', hair: 'spiky', size: 0.68, prop: 'ball'},
  RAJA:   {skin: '#9A6440', top: '#5B2A86', topKind: 'robe', bottom: '#5B2A86', trim: '#F2C230', hair: 'crown', stache: '#1B1212', size: 1.05, prop: null},
  VENDOR: {skin: '#6E4128', top: '#E8E2D0', topKind: 'shirt', bottom: '#2E7D5B', trim: '#E2B33C', hair: 'turban', stache: '#1B1212', size: 0.95, prop: null},
  PANDIT: {skin: '#94603E', top: '#F7EBD3', topKind: 'bare', bottom: '#F29B38', trim: '#B5651D', hair: 'tuft', namam: true, size: 0.95, prop: 'scroll'},
};

export const Local: React.FC<ToonProps & {kind: LocalKind}> = (p) => {
  const {kind, frame, talk, lookX = 0, lookY = 0, expr = 'neutral', armL = POSE.rest, armR = POSE.rest, tilt = 0, walk = 0} = p;
  const c = LOCALS[kind];
  const kid = kind === 'KUTTI';
  const skin = c.skin;
  const step = walk ? Math.sin(frame / 3) * 22 * walk : 0;
  const breathe = Math.sin(frame / 16) * 3, bob = talk > 0.1 ? Math.sin(frame / 3.4) * 3 : walk ? -Math.abs(Math.sin(frame / 3)) * 8 : 0;
  const headTilt = tilt + (talk > 0.1 ? Math.sin(frame / 7) * 4 : 0);
  const open = blinkOpen(frame, kind.length * 17);
  const sh = kid ? -330 : -385; // shoulder height
  const hy = kid ? -520 : -548; // head centre
  const hr = kid ? 130 : 124;
  const longBottom = c.topKind === 'saree' || c.topKind === 'robe' || kind === 'THATHA' || kind === 'PANDIT';
  return (
    <g>
      <ellipse cx={0} cy={4} rx={130} ry={18} fill="#000" opacity={0.18} />
      {!longBottom && [-1, 1].map((s) => (
        <g key={s}>
          <path d={`M${s * 34} ${kid ? -170 : -230} L${s * 40 + s * step} -28`} stroke={INK} strokeWidth={40} strokeLinecap="round" />
          <path d={`M${s * 34} ${kid ? -170 : -230} L${s * 40 + s * step} -28`} stroke={kid ? skin : c.bottom} strokeWidth={28} strokeLinecap="round" />
          <ellipse cx={s * 50 + s * step} cy={-12} rx={32} ry={15} fill={kid ? '#E2E2E2' : '#5B3A22'} stroke={INK} strokeWidth={5} />
        </g>
      ))}
      {longBottom && [-1, 1].map((s) => <ellipse key={s} cx={s * 46 + s * step * 0.5} cy={-12} rx={36} ry={16} fill={skin} stroke={INK} strokeWidth={5} />)}
      <g transform={`translate(0 ${breathe + bob})`}>
        {c.prop === 'staff' && <path d={`M${-190} -560 L-170 -10`} stroke="#7A4A22" strokeWidth={16} strokeLinecap="round" />}
        <ArmShape sx={-82} sy={sh} side={-1} a={armL} skin={skin} l1={kid ? 85 : 105} l2={kid ? 80 : 100} w={kid ? 26 : 32}
          sleeve={c.topKind === 'shirt' || c.topKind === 'robe' ? c.top : undefined}>
          {c.prop === 'fan' && <g transform="rotate(-20) translate(0,-60)"><path d="M0 40 L-55 -50 Q0 -80 55 -50 Z" fill="#D9B45B" stroke={INK} strokeWidth={5} />{[-30, -15, 0, 15, 30].map((a) => <line key={a} x1={0} y1={40} x2={a * 1.6} y2={-60} stroke="#8A6A25" strokeWidth={3} />)}</g>}
          {c.prop === 'scroll' && <g transform="rotate(-15)"><rect x={-20} y={-70} width={40} height={90} rx={6} fill="#E9D4A0" stroke={INK} strokeWidth={4} />{[-50, -35, -20].map((y) => <line key={y} x1={-12} x2={12} y1={y} y2={y} stroke="#8A6A25" strokeWidth={3} />)}</g>}
          {c.prop === 'ball' && <circle cy={-30} r={30} fill="#FF1E3C" stroke={INK} strokeWidth={5} />}
        </ArmShape>
        {/* lower body */}
        {longBottom && <>
          <path d={`M-118 -250 L${-108 - step * 0.3} -24 Q0 -10 ${108 + step * 0.3} -24 L118 -250 Z`} fill={c.bottom} stroke={INK} strokeWidth={6} />
          <path d="M-110 -50 Q0 -36 110 -50" stroke={c.trim} strokeWidth={12} fill="none" />
        </>}
        {!longBottom && !kid && <path d="M-100 -260 L-104 -200 Q0 -186 104 -200 L100 -260 Z" fill={c.bottom} stroke={INK} strokeWidth={6} />}
        {kid && <path d="M-80 -210 L-90 -150 Q0 -136 90 -150 L80 -210 Z" fill={c.bottom} stroke={INK} strokeWidth={6} />}
        {/* torso */}
        {kid
          ? <path d={`M-74 ${sh - 12} Q0 ${sh - 30} 74 ${sh - 12} L84 -200 Q0 -186 -84 -200 Z`} fill={c.top} stroke={INK} strokeWidth={6} />
          : <path d="M-86 -400 Q0 -424 86 -400 Q132 -310 112 -246 Q0 -224 -112 -246 Q-132 -310 -86 -400 Z" fill={c.topKind === 'bare' ? skin : c.top} stroke={INK} strokeWidth={6} />}
        {kid && <text x={0} y={-250} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={56} fill={c.trim}>★</text>}
        {c.topKind === 'bare' && <>
          <path d="M-80 -404 L90 -248" stroke={kind === 'PANDIT' ? '#F29B38' : '#FFF4DC'} strokeWidth={34} strokeLinecap="round" />
          <path d="M-80 -404 L90 -248" stroke={c.trim} strokeWidth={5} strokeDasharray="10 12" />
          {kind === 'PANDIT' && <path d="M-70 -400 Q10 -300 80 -250" stroke="#fff" strokeWidth={4} fill="none" />}
        </>}
        {c.topKind === 'saree' && <path d="M-86 -404 L-40 -404 L118 -250 L60 -240 Z" fill={c.trim} stroke={INK} strokeWidth={5} />}
        {c.topKind === 'robe' && <>
          <path d="M-90 -410 Q-150 -200 -130 -20 L-110 -20 Z" fill="#C62828" stroke={INK} strokeWidth={5} />
          <path d="M-60 -410 Q0 -330 60 -410" stroke={c.trim} strokeWidth={16} fill="none" />
          {[-40, 0, 40].map((x) => <circle key={x} cx={x} cy={-360 + Math.abs(x) * -0.6} r={11} fill="#E53935" stroke={INK} strokeWidth={3} />)}
          <rect x={-118} y={-262} width={236} height={22} fill={c.trim} stroke={INK} strokeWidth={4} />
        </>}
        {c.topKind === 'shirt' && !kid && <path d="M0 -414 L0 -240" stroke={INK} strokeWidth={4} />}
        <rect x={-18} y={sh - 65} width={36} height={56} fill={skin} stroke={INK} strokeWidth={5} />
        <g transform={`rotate(${headTilt} 0 ${sh - 55})`}>
          {[-1, 1].map((s) => <circle key={s} cx={s * (hr - 4)} cy={hy + 6} r={20} fill={skin} stroke={INK} strokeWidth={5} />)}
          {c.hair === 'bun' && <circle cx={0} cy={hy - hr + 4} r={48} fill="#D9D4CC" stroke={INK} strokeWidth={5} />}
          <circle cx={0} cy={hy} r={hr} fill={skin} stroke={INK} strokeWidth={6} />
          {c.hair === 'bald' && [-1, 1].map((s) => (
            <path key={s} d={`M${s * (hr - 6)} ${hy - 52} q${s * 30} 10 ${s * 22} 34 q${s * 26} 14 ${s * 8} 40 q${s * 10} 20 ${-s * 14} 22 Z`} fill="#F4F1EA" stroke={INK} strokeWidth={4} />
          ))}
          {c.hair === 'bun' && <path d={`M${-hr} ${hy + 4} C${-hr - 6} ${hy - hr - 40} ${hr + 6} ${hy - hr - 40} ${hr} ${hy + 4} C${hr - 20} ${hy - 70} ${-hr + 20} ${hy - 70} ${-hr} ${hy + 4} Z`} fill="#D9D4CC" stroke={INK} strokeWidth={5} />}
          {c.hair === 'spiky' && <path d={`M${-hr} ${hy - 10} L${-hr + 10} ${hy - hr - 10} L-60 ${hy - hr + 6} L-30 ${hy - hr - 40} L0 ${hy - hr + 4} L34 ${hy - hr - 38} L60 ${hy - hr + 6} L${hr - 10} ${hy - hr - 12} L${hr} ${hy - 10} C${hr - 30} ${hy - 80} ${-hr + 30} ${hy - 80} ${-hr} ${hy - 10} Z`} fill="#1B1212" stroke={INK} strokeWidth={5} />}
          {c.hair === 'crown' && <g>
            <path d={`M${-hr + 6} ${hy - 50} C${-hr} ${hy - hr - 20} ${hr} ${hy - hr - 20} ${hr - 6} ${hy - 50} C${hr - 30} ${hy - 90} ${-hr + 30} ${hy - 90} ${-hr + 6} ${hy - 50} Z`} fill="#1B1212" stroke={INK} strokeWidth={5} />
            <path d={`M-90 ${hy - 95} L-100 ${hy - 210} L-50 ${hy - 160} L0 ${hy - 235} L50 ${hy - 160} L100 ${hy - 210} L90 ${hy - 95} Z`} fill="#F2C230" stroke={INK} strokeWidth={6} />
            {[-50, 0, 50].map((x) => <circle key={x} cx={x} cy={hy - 125} r={12} fill={x ? '#2E9E4F' : '#E53935'} stroke={INK} strokeWidth={3} />)}
          </g>}
          {c.hair === 'turban' && <path d={`M${-hr - 6} ${hy - 30} C${-hr} ${hy - hr - 70} ${hr} ${hy - hr - 70} ${hr + 6} ${hy - 30} Q0 ${hy - 70} ${-hr - 6} ${hy - 30} Z`} fill="#E53935" stroke={INK} strokeWidth={6} />}
          {c.hair === 'tuft' && <path d={`M0 ${hy - hr + 2} q-30 -50 10 -70 q-10 30 14 66 Z`} fill="#1B1212" stroke={INK} strokeWidth={4} />}
          {c.vibhuti && [-84, -68, -52].map((y) => <rect key={y} x={-48} y={hy + y} width={96} height={8} rx={4} fill="#F7F3EA" />)}
          {c.vibhuti && <circle cx={0} cy={hy - 56} r={8} fill="#E0262E" />}
          {c.namam && <path d={`M-22 ${hy - 40} L-12 ${hy - 100} M22 ${hy - 40} L12 ${hy - 100} M0 ${hy - 40} L0 ${hy - 96}`} stroke="#fff" strokeWidth={9} strokeLinecap="round" />}
          {c.namam && <path d={`M0 ${hy - 40} L0 ${hy - 96}`} stroke="#E0262E" strokeWidth={7} strokeLinecap="round" />}
          {kind === 'PAATI' && <circle cx={0} cy={hy - 62} r={9} fill="#E0262E" />}
          <Eyes cx={0} cy={hy - 8} gap={42} rx={kid ? 28 : 21} ry={kid ? 33 : 25} open={open} lx={lookX} ly={lookY} expr={expr} brow={c.stache === '#F4F1EA' || c.hair === 'bun' ? '#F4F1EA' : '#1B1212'} browW={c.vibhuti ? 13 : 9} skin={skin} />
          {c.glasses && <g fill="none" stroke={INK} strokeWidth={6}><circle cx={-42} cy={hy - 8} r={34} /><circle cx={42} cy={hy - 8} r={34} /><path d={`M-8 ${hy - 10} L8 ${hy - 10}`} /></g>}
          <path d={`M-10 ${hy + 18} Q0 ${hy + 42} 12 ${hy + 20}`} stroke={INK} strokeWidth={6} fill="#00000022" />
          <Mouth x={0} y={hy + (kid ? 56 : 64)} talk={talk} expr={expr} w={kid ? 26 : 24} />
          {c.stache && <>
            <path d={`M0 ${hy + 36} C-30 ${hy + 28} -70 ${hy + 28} -92 ${hy + 52} C-102 ${hy + 64} -100 ${hy + 82} -86 ${hy + 78} C-80 ${hy + 62} -60 ${hy + 56} -40 ${hy + 58} C-20 ${hy + 60} -8 ${hy + 50} 0 ${hy + 48} Z`} fill={c.stache} stroke={INK} strokeWidth={5} transform={`rotate(${talk * 6} 0 ${hy + 43})`} />
            <path d={`M0 ${hy + 36} C30 ${hy + 28} 70 ${hy + 28} 92 ${hy + 52} C102 ${hy + 64} 100 ${hy + 82} 86 ${hy + 78} C80 ${hy + 62} 60 ${hy + 56} 40 ${hy + 58} C20 ${hy + 60} 8 ${hy + 50} 0 ${hy + 48} Z`} fill={c.stache} stroke={INK} strokeWidth={5} transform={`rotate(${-talk * 6} 0 ${hy + 43})`} />
          </>}
          {(kind === 'PAATI' || kind === 'RAJA' || kind === 'THATHA') && [-1, 1].map((s) => <circle key={s} cx={s * (hr + 2)} cy={hy + 36} r={9} fill="#F2C230" stroke={INK} strokeWidth={3} />)}
        </g>
        <ArmShape sx={82} sy={sh} side={1} a={armR} skin={skin} l1={kid ? 85 : 105} l2={kid ? 80 : 100} w={kid ? 26 : 32}
          sleeve={c.topKind === 'shirt' || c.topKind === 'robe' ? c.top : undefined} />
      </g>
    </g>
  );
};

// back-compat for the first test episode
export const Thatha: React.FC<ToonProps> = (p) => <Local {...p} kind="THATHA" />;
