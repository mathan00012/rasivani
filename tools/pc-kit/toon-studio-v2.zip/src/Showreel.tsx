// VANI model sheet in motion: 4 looks, expressions, gestures, walk; then the local cast.
import React from 'react';
import {AbsoluteFill, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Vani, Local, LOOKS, POSE, INK, Look, Expr, LocalKind, LOCALS} from './Toon';
import {Background} from './Scenes';
import {fontCss} from './Episode';

const EXPRS: Expr[] = ['happy', 'shock', 'smirk', 'confused', 'angry', 'sheepish', 'think', 'sad', 'stern', 'neutral'];
const MOVES = ['wave', 'cheer', 'point', 'shrug', 'think', 'facepalm', 'stop', 'hip'];

export const Showreel: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const looks = Object.keys(LOOKS) as Look[];
  const part2 = f >= 330;
  const ei = Math.floor(f / 30) % EXPRS.length, mi = Math.floor(f / 30) % MOVES.length;
  const label = (t: string, x: number, y: number, s = 44) => <text x={x} y={y} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={s} fill="#fff" stroke={INK} strokeWidth={10} paintOrder="stroke">{t}</text>;
  return (
    <AbsoluteFill style={{background: '#120C33'}}>
      <style>{fontCss(staticFile)}</style>
      <svg width={1920} height={1080} viewBox="0 0 1920 1080">
        <g transform="translate(960 540) scale(0.94) translate(-540 -1000)"><Background name={part2 ? 'village' : 'studio'} frame={f} /></g>
        {!part2 && looks.map((lk, i) => {
          const s = spring({frame: f - 10 - i * 12, fps, config: {damping: 12}});
          const walk = interpolate(f, [10 + i * 12, 50 + i * 12], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
          const x = 270 + i * 460 + walk * 1400;
          const talk = f > 120 && (Math.floor(f / 8) + i) % 3 === 0 ? 0.3 + 0.5 * Math.abs(Math.sin(f / 2 + i)) : 0;
          const g = POSE[MOVES[(mi + i) % MOVES.length]];
          return (
            <g key={lk} transform={`translate(${x} 960) scale(${0.72 * Math.max(s, 0.01)})`}>
              <Vani frame={f + i * 7} talk={talk} expr={f < 60 ? 'happy' : EXPRS[(ei + i) % EXPRS.length]} armR={POSE.mic} armL={f < 60 ? POSE.rest : g} prop="micphone" look={lk} walk={walk > 0.02 ? 1 : 0} lookX={walk > 0 ? -1 : 0} />
            </g>
          );
        })}
        {!part2 && looks.map((lk, i) => <g key={'l' + lk}>{label(LOOKS[lk].label, 270 + i * 460, 1040, 38)}</g>)}
        {part2 && (Object.keys(LOCALS) as LocalKind[]).map((k, i) => {
          const s = spring({frame: f - 335 - i * 8, fps, config: {damping: 11}});
          const talk = (Math.floor(f / 10) % 6) === i ? 0.6 * Math.abs(Math.sin(f / 2)) : 0;
          const x = 170 + i * 316;
          return <g key={k}><g transform={`translate(${x} 960) scale(${0.62 * Math.max(s, 0.01)})`}>
            <Local kind={k} frame={f + i * 9} talk={talk} expr={EXPRS[(ei + i * 2) % EXPRS.length]} armR={POSE[MOVES[(mi + i) % MOVES.length]]} lookX={i < 3 ? 1 : -1} />
          </g>{label(k, x, 1040, 40)}</g>;
        })}
      </svg>
      <div style={{position: 'absolute', top: 30, width: '100%', textAlign: 'center', fontFamily: 'BalooTa', fontWeight: 800, fontSize: 84, color: '#FFE14D', WebkitTextStroke: `12px ${INK}`, paintOrder: 'stroke fill'}}>
        {part2 ? 'VANI meets… the cast' : f < 120 ? 'VANI — 4 looks' : '10 expressions · 11 gestures · walk · lip-sync'}
      </div>
    </AbsoluteFill>
  );
};
