// "ராகு காலம்னா என்ன?" — RasiVani cartoon Short #1 (Tamil, 9:16)
import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, Easing, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Vani, Thatha, INK, Arm, Expr} from './Toon';
import timing from './timing.json';

const L: Record<string, any> = Object.fromEntries(timing.lines.map((l: any) => [l.id, l]));
const end = (id: string) => L[id].start + L[id].frames;
const P0 = end('l1') + 2;          // portal starts
const SWITCH = P0 + 12;            // scene changes to the old village

const fontCss = `
@font-face { font-family: BalooTa; src: url(${staticFile('fonts/baloo-ta.woff2')}); }
@font-face { font-family: BalooTa; src: url(${staticFile('fonts/baloo-la.woff2')}); unicode-range: U+0000-00FF; }`;

// mouth openness for a speaker at this frame
const talkOf = (frame: number, who: string) => {
  for (const l of timing.lines as any[]) {
    if (l.who !== who) continue;
    const i = frame - l.start;
    if (i >= 0 && i < l.frames) return l.amp[i];
  }
  return 0;
};

// keyframe helper: [[frame, value], ...] with ease, numbers or objects of numbers
function kf<T>(frame: number, keys: [number, T][], dur = 6): T {
  let v = keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    const [f, nv] = keys[i];
    if (frame < f) break;
    const p = interpolate(frame, [f, f + dur], [0, 1], {extrapolateRight: 'clamp', easing: Easing.out(Easing.back(1.6))});
    if (typeof nv === 'number') v = ((v as any) + ((nv as any) - (v as any)) * p) as any;
    else { const o: any = {}; for (const k in nv as any) o[k] = (v as any)[k] + ((nv as any)[k] - (v as any)[k]) * p; v = o; }
  }
  return v;
}
function pick<T>(frame: number, keys: [number, T][]): T { let v = keys[0][1]; for (const [f, nv] of keys) if (frame >= f) v = nv; return v; }

const POSE: Record<string, Arm> = {
  rest: {t: 12, b: -8}, mic: {t: 30, b: -150}, wave: {t: 110, b: 20}, stop: {t: 78, b: 88},
  phone: {t: 22, b: -125}, phoneUp: {t: 60, b: -150}, point: {t: 92, b: -6}, hip: {t: 40, b: -120}, fan: {t: 30, b: -140}, shrug: {t: 60, b: 70},
};

// ── Captions: big bold chunks, 2 words at a time ──
const Captions: React.FC<{frame: number}> = ({frame}) => {
  for (const l of timing.lines as any[]) {
    const i = frame - l.start;
    if (i < 0 || i >= l.frames + 6) continue;
    const words = l.text.split(' ');
    const chunks: string[] = [];
    for (let k = 0; k < words.length; k += 2) chunks.push(words.slice(k, k + 2).join(' '));
    const total = chunks.reduce((a, c) => a + c.length, 0);
    let acc = 0, idx = 0;
    for (let k = 0; k < chunks.length; k++) { if (i >= (acc / total) * l.frames) idx = k; acc += chunks[k].length; }
    const startOf = (chunks.slice(0, idx).reduce((a, c) => a + c.length, 0) / total) * l.frames;
    const pop = interpolate(i - startOf, [0, 4], [0.7, 1], {extrapolateRight: 'clamp', easing: Easing.out(Easing.back(3))});
    const color = l.who === 'VANI' ? '#FFE14D' : '#FFFFFF';
    return (
      <div style={{position: 'absolute', left: 60, right: 60, top: 1470, textAlign: 'center', transform: `scale(${pop})`}}>
        <span style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 92, lineHeight: 1.15, color, WebkitTextStroke: `14px ${INK}`, paintOrder: 'stroke fill', textShadow: '0 8px 0 rgba(0,0,0,.35)'}}>
          {chunks[idx]}
        </span>
      </div>
    );
  }
  return null;
};

// ── Scene A: RasiVani studio, today ──
const Studio: React.FC<{frame: number}> = ({frame}) => (
  <g>
    <defs>
      <radialGradient id="sg" cx="50%" cy="40%" r="70%"><stop offset="0" stopColor="#3B2A8C" /><stop offset="1" stopColor="#120C33" /></radialGradient>
    </defs>
    <rect x={-700} y={-400} width={2480} height={2800} fill="url(#sg)" />
    <g transform={`translate(540 760) rotate(${frame * 0.4})`} opacity={0.5}>
      <circle r={420} fill="none" stroke="#FFC93C" strokeWidth={6} />
      <circle r={330} fill="none" stroke="#FFC93C" strokeWidth={3} />
      {[...Array(12)].map((_, i) => <g key={i} transform={`rotate(${i * 30})`}><line x1={0} y1={-330} x2={0} y2={-420} stroke="#FFC93C" strokeWidth={3} /><circle cx={0} cy={-375} r={16} fill={i % 2 ? '#00E5FF' : '#FF1E3C'} /></g>)}
    </g>
    {[...Array(26)].map((_, i) => <circle key={i} cx={(i * 397) % 1080} cy={(i * 211) % 1100} r={3 + (i % 3)} fill="#fff" opacity={0.3 + 0.5 * Math.abs(Math.sin(frame / 10 + i))} />)}
    <rect x={-700} y={1560} width={2480} height={900} fill="#1E1650" />
    <rect x={-700} y={1556} width={2480} height={8} fill="#FFC93C" />
  </g>
);

// ── Scene B: an old Tamil village market ──
const Village: React.FC<{frame: number}> = ({frame}) => {
  const walker = (x0: number, speed: number, y: number, s: number, c: string, pot: boolean, k: number) => {
    const x = ((x0 + frame * speed) % 1500) - 200;
    const step = Math.sin(frame / 4 + k) * 10;
    return (
      <g key={k} transform={`translate(${x} ${y}) scale(${s})`} opacity={0.85}>
        <path d={`M-14 -90 L${-14 - step} 0 M14 -90 L${14 + step} 0`} stroke="#5B3A29" strokeWidth={14} strokeLinecap="round" />
        <path d="M-34 -200 L34 -200 L44 -80 L-44 -80 Z" fill={c} stroke={INK} strokeWidth={4} />
        <circle cy={-236} r={34} fill="#6B4129" stroke={INK} strokeWidth={4} />
        {pot && <><ellipse cy={-282} rx={36} ry={26} fill="#B5562B" stroke={INK} strokeWidth={4} /><path d="M-34 -260 L34 -260 L0 -300 Z" fill="none" stroke={INK} strokeWidth={0} /><path d="M-30 -270 Q0 -330 30 -270" stroke="#5B3A29" strokeWidth={6} fill="none" /></>}
      </g>
    );
  };
  return (
    <g>
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FF9E4A" /><stop offset="0.6" stopColor="#FFD48A" /><stop offset="1" stopColor="#FFE9B8" /></linearGradient>
      </defs>
      <rect x={-700} y={-400} width={2480} height={2800} fill="url(#sky)" />
      <circle cx={820} cy={380} r={90} fill="#FFF2B0" opacity={0.9} />
      {/* temple tower silhouette */}
      <g transform="translate(560 1120)" fill="#C9743F" stroke="#9A5228" strokeWidth={4} opacity={0.85}>
        <path d="M-200 0 L-165 -150 L165 -150 L200 0 Z" />
        <path d="M-165 -150 L-135 -280 L135 -280 L165 -150 Z" />
        <path d="M-135 -280 L-105 -390 L105 -390 L135 -280 Z" />
        <path d="M-105 -390 L-80 -480 L80 -480 L105 -390 Z" />
        <rect x={-95} y={-530} width={190} height={50} rx={24} />
        {[-50, 0, 50].map((x) => <path key={x} d={`M${x} -530 l-8 -26 l8 -18 l8 18 Z`} fill="#E8B23A" />)}
      </g>
      {/* palms */}
      {[[80, 1150, 1], [990, 1180, 0.9], [180, 1220, 0.7]].map(([x, y, s], k) => (
        <g key={k} transform={`translate(${x} ${y}) scale(${s})`}>
          <path d="M0 0 Q20 -250 -10 -480" stroke="#6E4524" strokeWidth={26} fill="none" />
          {[...Array(7)].map((_, i) => <path key={i} d="M-10 -480 q90 -40 170 40" stroke="#2F7A3B" strokeWidth={22} fill="none" strokeLinecap="round" transform={`rotate(${i * 51 + Math.sin(frame / 20 + i) * 4} -10 -480)`} />)}
        </g>
      ))}
      <rect x={-700} y={1120} width={2480} height={1300} fill="#D7A86E" />
      <path d="M-700 1120 Q540 1080 1780 1120 L1780 1180 L-700 1180 Z" fill="#C8945A" />
      {walker(0, 3.2, 1235, 0.85, '#3E7CB1', true, 1)}
      {walker(700, 2.1, 1255, 0.8, '#C2410C', false, 2)}
      {walker(1150, 2.7, 1215, 0.7, '#7E22CE', true, 3)}
      {/* cow */}
      <g transform={`translate(${1040 + Math.sin(frame / 30) * 6} 1250) scale(0.6)`}>
        <ellipse cx={0} cy={-90} rx={110} ry={55} fill="#F5F0E6" stroke={INK} strokeWidth={5} />
        {[-70, -30, 40, 80].map((x) => <rect key={x} x={x - 9} y={-50} width={18} height={60} fill="#F5F0E6" stroke={INK} strokeWidth={4} />)}
        <g transform={`rotate(${Math.sin(frame / 12) * 5} -110 -110)`}>
          <ellipse cx={-130} cy={-110} rx={40} ry={32} fill="#F5F0E6" stroke={INK} strokeWidth={5} />
          <path d="M-150 -138 q-10 -30 -24 -34 M-112 -138 q10 -30 24 -34" stroke="#C47A2C" strokeWidth={8} fill="none" strokeLinecap="round" />
          <circle cx={-140} cy={-112} r={5} fill={INK} />
        </g>
      </g>
    </g>
  );
};

// the stall goes IN FRONT of Thatha
const Stall: React.FC<{frame: number}> = ({frame}) => (
  <g>
    <rect x={110} y={1200} width={20} height={380} fill="#7A4A22" stroke={INK} strokeWidth={4} />
    <rect x={500} y={1200} width={20} height={380} fill="#7A4A22" stroke={INK} strokeWidth={4} />
    <rect x={90} y={1300} width={450} height={290} rx={10} fill="#A8642E" stroke={INK} strokeWidth={6} />
    {[1340, 1400, 1460, 1520].map((y) => <line key={y} x1={95} x2={535} y1={y} y2={y} stroke="#7A4A22" strokeWidth={4} />)}
    <rect x={75} y={1285} width={480} height={28} rx={8} fill="#7A4A22" stroke={INK} strokeWidth={5} />
    {[150, 230].map((x, i) => <g key={x}><ellipse cx={x} cy={1252} rx={42} ry={36} fill={i ? '#B5562B' : '#8F3F1E'} stroke={INK} strokeWidth={5} /><rect x={x - 22} y={1206} width={44} height={14} rx={6} fill="#6F2E14" stroke={INK} strokeWidth={4} /></g>)}
    {[0, 1, 2, 3, 4].map((i) => <path key={i} d={`M${330 + i * 18} 1278 q-6 -60 30 -80`} stroke="#F2C230" strokeWidth={22} fill="none" strokeLinecap="round" />)}
    <path d="M330 1282 q60 -20 100 0" stroke={INK} strokeWidth={3} fill="none" />
    <circle cx={480} cy={1258} r={30} fill="#6B3E1E" stroke={INK} strokeWidth={5} />
    {/* thatched roof (sways a little) */}
    <g transform={`rotate(${Math.sin(frame / 25) * 0.6} 320 700)`}>
      <path d="M40 760 L320 640 L600 760 Z" fill="#C99A4B" stroke={INK} strokeWidth={6} />
      {[...Array(14)].map((_, i) => <line key={i} x1={60 + i * 38} y1={762} x2={320} y2={650} stroke="#9A7432" strokeWidth={3} />)}
      <path d="M40 760 q40 22 80 0 q40 22 80 0 q40 22 80 0 q40 22 80 0 q40 22 80 0 q40 22 80 0 q40 22 80 0" fill="#C99A4B" stroke={INK} strokeWidth={5} />
    </g>
  </g>
);

// ── Infographic: daytime split into 8 parts, one is Rahu kalam ──
const DayArc: React.FC<{frame: number; at: number}> = ({frame, at}) => {
  const {fps} = useVideoConfig();
  const s = spring({frame: frame - at, fps, config: {damping: 11}});
  const shown = Math.floor(interpolate(frame - at, [4, 30], [0, 8], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}));
  const hi = 7; // Sunday: the 8th part (4:30–6:00 PM)
  const R = 300;
  const wedge = (i: number) => {
    const a0 = Math.PI + (i * Math.PI) / 8, a1 = Math.PI + ((i + 1) * Math.PI) / 8;
    return `M0 0 L${R * Math.cos(a0)} ${R * Math.sin(a0)} A${R} ${R} 0 0 1 ${R * Math.cos(a1)} ${R * Math.sin(a1)} Z`;
  };
  return (
    <g transform={`translate(540 640) scale(${s})`}>
      <rect x={-400} y={-400} width={800} height={520} rx={40} fill="#FFF8E7" stroke={INK} strokeWidth={8} />
      {[...Array(8)].map((_, i) => <path key={i} d={wedge(i)} fill={i === hi && shown > i ? '#FF1E3C' : i < shown ? (i % 2 ? '#FFC93C' : '#FFE08A') : '#EEE'} stroke={INK} strokeWidth={5}
        transform={i === hi && shown > i ? `scale(${1 + 0.06 * Math.abs(Math.sin(frame / 4))})` : ''} />)}
      <circle r={40} fill="#FFB020" stroke={INK} strokeWidth={6} />
      <text x={-330} y={60} fontFamily="BalooTa" fontWeight={800} fontSize={40} fill={INK}>6 AM</text>
      <text x={210} y={60} fontFamily="BalooTa" fontWeight={800} fontSize={40} fill={INK}>6 PM</text>
      <text x={0} y={105} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={44} fill="#FF1E3C">ஞாயிறு: 4:30 – 6:00 PM</text>
      <text x={0} y={-330} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={56} fill={INK}>பகல் = 8 பங்கு</text>
      {shown >= 8 && <g transform={`translate(250 -230) rotate(-6) scale(${spring({frame: frame - at - 30, fps, config: {damping: 9}})})`}>
        <rect x={-120} y={-50} width={240} height={90} rx={20} fill="#FF1E3C" stroke={INK} strokeWidth={6} />
        <text x={0} y={18} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={50} fill="#fff">1½ மணி</text>
      </g>}
    </g>
  );
};

export const RahuKalam: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const inVillage = frame >= SWITCH;
  const tV = talkOf(frame, 'VANI'), tT = talkOf(frame, 'THATHA');
  const l2 = L.l2.start, l3 = L.l3.start, l4 = L.l4.start, l5 = L.l5.start, l6 = L.l6.start;
  const l5mid = l5 + Math.round(L.l5.frames * 0.55);
  const outro = end('l6') - 4;

  // camera keyframes: {x, y, z}
  const cam = inVillage
    ? kf(frame, [
        [SWITCH, {x: 540, y: 960, z: 1}], [l2 - 4, {x: 330, y: 1000, z: 1.45}], [l3 - 2, {x: 760, y: 1050, z: 1.5}],
        [l4 - 2, {x: 540, y: 1000, z: 1.0}], [l5 - 2, {x: 330, y: 960, z: 1.6}], [l5mid, {x: 780, y: 1040, z: 1.75}],
        [l6 - 2, {x: 700, y: 1000, z: 1.3}],
      ], 7)
    : kf(frame, [[0, {x: 540, y: 1000, z: 1.25}], [L.l1.start + 40, {x: 540, y: 960, z: 1.4}]], 20);
  const shake = (frame >= l5 && frame < l5 + 8) ? Math.sin(frame * 3) * 10 : 0;

  // VANI acting
  const vArmR = inVillage ? kf(frame, [[0, POSE.mic], [l3 - 2, POSE.shrug], [l3 + 30, POSE.rest], [l6 - 2, POSE.mic]]) : POSE.mic;
  const vArmL = inVillage ? kf(frame, [[0, POSE.rest], [l2 + 10, POSE.hip], [l5mid - 2, POSE.phone], [l6 - 2, POSE.phoneUp]]) : kf(frame, [[0, POSE.rest], [L.l1.start + 20, POSE.wave], [L.l1.start + 45, POSE.rest]]);
  const vExpr: Expr = inVillage ? pick<Expr>(frame, [[0, 'shock'], [l2 + 40, 'neutral'], [l3, 'confused'], [l4, 'neutral'], [l4 + 50, 'happy'], [l5mid, 'sheepish'], [l6, 'happy']]) : 'happy';
  const vLook = inVillage ? (frame >= l5mid && frame < l6 ? {x: 0.2, y: 0.9} : frame >= l6 ? {x: 0, y: 0} : {x: -1, y: 0}) : {x: 0, y: 0};
  // Thatha acting
  const tArmR = kf(frame, [[0, POSE.stop], [l3, POSE.rest], [l4, POSE.wave], [l4 + 40, POSE.rest], [l5, POSE.point], [l6, POSE.rest]]);
  const tArmL = kf(frame, [[0, POSE.fan], [l2, POSE.fan]]);
  const tExpr: Expr = pick<Expr>(frame, [[0, 'stern'], [l3, 'neutral'], [l4, 'happy'], [l5, 'smirk'], [l6, 'happy']]);
  const fanWave = Math.sin(frame / 3) * 10;

  const vx = inVillage ? kf(frame, [[SWITCH, 1200], [SWITCH + 1, 780]], 10) : 540;

  // portal
  const pr = interpolate(frame, [P0, SWITCH, SWITCH + 12], [0, 1600, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  const hookS = spring({frame: frame - 2, fps, config: {damping: 8}});
  const outroS = spring({frame: frame - outro, fps, config: {damping: 10}});

  return (
    <AbsoluteFill style={{backgroundColor: '#120C33'}}>
      <style>{fontCss}</style>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920">
        <g transform={`translate(${540 + shake} 960) scale(${Math.max(cam.z, inVillage ? 1.04 : 1)}) translate(${-cam.x} ${-cam.y})`}>
          {inVillage ? (
            <>
              <Village frame={frame} />
              <g transform="translate(320 1500) scale(0.95)">
                <Thatha frame={frame} talk={tT} lookX={frame >= l6 ? 0.2 : 1} expr={tExpr} armR={tArmR} armL={{...tArmL, b: tArmL.b + fanWave}} prop="fan" />
              </g>
              <Stall frame={frame} />
              <g transform={`translate(${vx} 1620) scale(0.95)`}>
                <Vani frame={frame} talk={tV} lookX={vLook.x} lookY={vLook.y} expr={vExpr} armR={vArmR} armL={vArmL} prop="micphone"
                  phoneText={frame >= l6} sweat={frame >= l5mid && frame < l6} tilt={frame >= l3 && frame < l4 ? -8 : 0} />
              </g>
            </>
          ) : (
            <>
              <Studio frame={frame} />
              <g transform="translate(540 1600) scale(1.05)">
                <Vani frame={frame} talk={tV} expr="happy" armR={vArmR} armL={vArmL} prop="mic" />
              </g>
            </>
          )}
        </g>
        {/* time portal */}
        {pr > 0 && <g transform={`translate(540 900) rotate(${frame * 12})`}>
          {[1, 0.8, 0.6, 0.4, 0.2].map((k, i) => <circle key={i} r={pr * k} fill={i % 2 ? '#00E5FF' : '#FF1E3C'} stroke={INK} strokeWidth={10} />)}
          {[...Array(8)].map((_, i) => <path key={i} d={`M0 0 Q${pr * 0.3} ${-pr * 0.1} ${pr * 0.5} ${pr * 0.2}`} stroke="#FFE14D" strokeWidth={16} fill="none" transform={`rotate(${i * 45})`} />)}
        </g>}
        {inVillage && frame < l2 + 40 && <g transform={`translate(540 230) scale(${spring({frame: frame - SWITCH - 6, fps, config: {damping: 10}})})`}>
          <rect x={-330} y={-60} width={660} height={110} rx={55} fill="#FFF8E7" stroke={INK} strokeWidth={7} />
          <text x={0} y={22} textAnchor="middle" fontFamily="BalooTa" fontWeight={800} fontSize={60} fill={INK}>பழைய தமிழ் ஊர்</text>
        </g>}
        {frame >= l4 && frame < l5 && <DayArc frame={frame} at={l4 + 2} />}
      </svg>

      {/* hook title */}
      {frame < P0 && <div style={{position: 'absolute', top: 150, width: '100%', textAlign: 'center', transform: `scale(${hookS}) rotate(${Math.sin(frame / 3) * 2}deg)`}}>
        <span style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 150, color: '#FF1E3C', WebkitTextStroke: `16px #FFF8E7`, paintOrder: 'stroke fill'}}>ராகு காலம்?!</span>
      </div>}
      <Captions frame={frame} />
      {/* outro card */}
      {frame >= outro && <div style={{position: 'absolute', left: 90, right: 90, top: 300, padding: '36px 20px', borderRadius: 40, background: '#FFF8E7', border: `8px solid ${INK}`, textAlign: 'center', transform: `scale(${outroS})`}}>
        <div style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 64, color: INK, lineHeight: 1.2}}>உங்க ஊர் ராகு காலம்</div>
        <div style={{fontFamily: 'BalooTa', fontWeight: 800, fontSize: 84, color: '#FF1E3C'}}>rasivani.com</div>
      </div>}
      <div style={{position: 'absolute', top: 40, right: 40, fontFamily: 'BalooTa', fontWeight: 800, fontSize: 40, color: '#fff', opacity: 0.85, WebkitTextStroke: `6px ${INK}`, paintOrder: 'stroke fill'}}>RasiVani</div>

      {(timing.lines as any[]).map((l) => <Sequence key={l.id} from={l.start}><Audio src={staticFile(`voice/${l.id}.wav`)} /></Sequence>)}
      <Sequence from={P0}><Audio src={staticFile('whoosh.wav')} volume={0.7} /></Sequence>
      <Sequence from={L.l4.start + 34}><Audio src={staticFile('ding.wav')} /></Sequence>
      <Sequence from={outro}><Audio src={staticFile('ding.wav')} /></Sequence>
      {[0, L.l3.start, L.l5.start, l5mid, L.l6.start].map((f, i) => <Sequence key={i} from={f}><Audio src={staticFile('pop.wav')} volume={0.5} /></Sequence>)}
    </AbsoluteFill>
  );
};
