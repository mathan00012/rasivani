// Backgrounds. World is 1080 wide (portrait) but drawn from x -700..1780 so the camera can pan/zoom and 16:9 works.
import React from 'react';
import {INK} from './Toon';

export const SCENES = ['studio', 'village', 'temple', 'palace', 'home', 'sky', 'market'] as const;
export type SceneName = typeof SCENES[number];
const X0 = -700, W = 2480;

const Walkers: React.FC<{frame: number; colors: string[]; y: number}> = ({frame, colors, y}) => (
  <g>
    {colors.map((c, k) => {
      const speed = 1.6 + k * 0.7, dir = k % 2 ? -1 : 1;
      const x = dir > 0 ? ((k * 610 + frame * speed) % 2600) - 760 : 1840 - ((k * 610 + frame * speed) % 2600);
      const step = Math.sin(frame / 4 + k) * 10, s = 0.62 + (k % 3) * 0.08;
      return (
        <g key={k} transform={`translate(${x} ${y + (k % 3) * 22}) scale(${s * dir} ${s})`} opacity={0.8}>
          <path d={`M-14 -90 L${-14 - step} 0 M14 -90 L${14 + step} 0`} stroke="#5B3A29" strokeWidth={14} strokeLinecap="round" />
          <path d="M-34 -200 L34 -200 L44 -80 L-44 -80 Z" fill={c} stroke={INK} strokeWidth={4} />
          <circle cy={-236} r={34} fill="#6B4129" stroke={INK} strokeWidth={4} />
          {k % 2 === 0 && <ellipse cy={-282} rx={36} ry={26} fill="#B5562B" stroke={INK} strokeWidth={4} />}
        </g>
      );
    })}
  </g>
);

const Palm: React.FC<{x: number; y: number; s: number; frame: number}> = ({x, y, s, frame}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M0 0 Q20 -250 -10 -480" stroke="#6E4524" strokeWidth={26} fill="none" />
    {[...Array(7)].map((_, i) => <path key={i} d="M-10 -480 q90 -40 170 40" stroke="#2F7A3B" strokeWidth={22} fill="none" strokeLinecap="round" transform={`rotate(${i * 51 + Math.sin(frame / 20 + i) * 4} -10 -480)`} />)}
  </g>
);

const Gopuram: React.FC<{x: number; y: number; s: number; fill?: string}> = ({x, y, s, fill = '#C9743F'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={fill} stroke="#9A5228" strokeWidth={4}>
    <path d="M-200 0 L-165 -150 L165 -150 L200 0 Z" /><path d="M-165 -150 L-135 -280 L135 -280 L165 -150 Z" />
    <path d="M-135 -280 L-105 -390 L105 -390 L135 -280 Z" /><path d="M-105 -390 L-80 -480 L80 -480 L105 -390 Z" />
    <rect x={-95} y={-530} width={190} height={50} rx={24} />
    {[-50, 0, 50].map((x) => <path key={x} d={`M${x} -530 l-8 -26 l8 -18 l8 18 Z`} fill="#E8B23A" />)}
  </g>
);

const Sky: React.FC<{top: string; mid: string; bot: string; id: string}> = ({top, mid, bot, id}) => (
  <>
    <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={top} /><stop offset="0.6" stopColor={mid} /><stop offset="1" stopColor={bot} /></linearGradient></defs>
    <rect x={X0} y={-400} width={W} height={2800} fill={`url(#${id})`} />
  </>
);
const Ground: React.FC<{c1: string; c2: string}> = ({c1, c2}) => (
  <>
    <rect x={X0} y={1120} width={W} height={1300} fill={c1} />
    <path d={`M${X0} 1120 Q540 1080 1780 1120 L1780 1180 L${X0} 1180 Z`} fill={c2} />
  </>
);

export const Background: React.FC<{name: string; frame: number}> = ({name, frame}) => {
  switch (name) {
    case 'studio':
      return (
        <g>
          <defs><radialGradient id="sg" cx="50%" cy="40%" r="70%"><stop offset="0" stopColor="#3B2A8C" /><stop offset="1" stopColor="#120C33" /></radialGradient></defs>
          <rect x={X0} y={-400} width={W} height={2800} fill="url(#sg)" />
          <g transform={`translate(540 760) rotate(${frame * 0.4})`} opacity={0.5}>
            <circle r={420} fill="none" stroke="#FFC93C" strokeWidth={6} /><circle r={330} fill="none" stroke="#FFC93C" strokeWidth={3} />
            {[...Array(12)].map((_, i) => <g key={i} transform={`rotate(${i * 30})`}><line x1={0} y1={-330} x2={0} y2={-420} stroke="#FFC93C" strokeWidth={3} /><circle cx={0} cy={-375} r={16} fill={i % 2 ? '#00E5FF' : '#FF1E3C'} /></g>)}
          </g>
          {[...Array(40)].map((_, i) => <circle key={i} cx={X0 + ((i * 397) % W)} cy={(i * 211) % 1100} r={3 + (i % 3)} fill="#fff" opacity={0.3 + 0.5 * Math.abs(Math.sin(frame / 10 + i))} />)}
          <rect x={X0} y={1560} width={W} height={900} fill="#1E1650" /><rect x={X0} y={1556} width={W} height={8} fill="#FFC93C" />
        </g>
      );
    case 'temple':
      return (
        <g>
          <Sky top="#7FC8F8" mid="#CDEBFF" bot="#FFF1C9" id="tsky" />
          <Gopuram x={540} y={1130} s={1.5} />
          <Gopuram x={-260} y={1130} s={0.8} fill="#D88A55" /><Gopuram x={1340} y={1130} s={0.8} fill="#D88A55" />
          <Ground c1="#E6D3B0" c2="#D8C29A" />
          {[...Array(9)].map((_, i) => <rect key={i} x={X0 + 120 + i * 280} y={1140} width={40} height={300} fill="#EADBC0" stroke="#B89B6A" strokeWidth={4} />)}
          {[...Array(5)].map((_, i) => <g key={i} transform={`translate(${-300 + i * 420} 1430)`}><rect x={-14} y={-40} width={28} height={40} fill="#B5651D" stroke={INK} strokeWidth={3} /><ellipse cx={0} cy={-48 - Math.abs(Math.sin(frame / 5 + i)) * 6} rx={9} ry={16} fill="#FFB020" /></g>)}
          <Walkers frame={frame} colors={['#C2410C', '#7E22CE', '#0E7490']} y={1250} />
        </g>
      );
    case 'palace':
      return (
        <g>
          <rect x={X0} y={-400} width={W} height={2800} fill="#5A1E3A" />
          {[...Array(10)].map((_, i) => <g key={i}><rect x={X0 + i * 270} y={300} width={60} height={900} fill="#C9973A" stroke={INK} strokeWidth={5} /><path d={`M${X0 + i * 270 + 60} 420 Q${X0 + i * 270 + 165} 300 ${X0 + i * 270 + 270} 420`} fill="none" stroke="#E8B23A" strokeWidth={10} /></g>)}
          <path d="M140 1200 L140 520 Q540 380 940 520 L940 1200 Z" fill="#8E244D" stroke="#E8B23A" strokeWidth={10} />
          <rect x={360} y={880} width={360} height={260} rx={30} fill="#E8B23A" stroke={INK} strokeWidth={6} />
          <rect x={X0} y={1150} width={W} height={1300} fill="#3A1426" />
          {[...Array(20)].map((_, i) => <path key={i} d={`M${X0 + i * 130} 1160 l65 40 l65 -40`} stroke="#E8B23A" strokeWidth={4} fill="none" opacity={0.6} />)}
          <rect x={200} y={1170} width={680} height={600} fill="#B71C1C" opacity={0.85} />
        </g>
      );
    case 'home':
      return (
        <g>
          <rect x={X0} y={-400} width={W} height={2800} fill="#F6E3C1" />
          <rect x={X0} y={-400} width={W} height={700} fill="#E9CFA0" />
          <rect x={180} y={420} width={300} height={360} rx={12} fill="#9ED8F5" stroke="#7A4A22" strokeWidth={18} />
          <line x1={330} y1={420} x2={330} y2={780} stroke="#7A4A22" strokeWidth={10} />
          <g transform="translate(800 520)"><circle r={80} fill="#FFF8E7" stroke={INK} strokeWidth={8} />
            <line x1={0} y1={0} x2={0} y2={-55} stroke={INK} strokeWidth={8} strokeLinecap="round" transform={`rotate(${frame * 2})`} />
            <line x1={0} y1={0} x2={38} y2={0} stroke="#FF1E3C" strokeWidth={8} strokeLinecap="round" transform={`rotate(${frame * 0.2})`} /></g>
          <g transform="translate(-200 600)"><rect x={-90} y={-130} width={180} height={150} fill="#FFF" stroke="#C9973A" strokeWidth={10} /><circle cy={-55} r={40} fill="#F2B705" /></g>
          <rect x={X0} y={1120} width={W} height={1300} fill="#B5562B" />
          {[...Array(14)].map((_, i) => <rect key={i} x={X0 + i * 180} y={1120} width={180} height={1300} fill="none" stroke="#8F3F1E" strokeWidth={4} />)}
          <g transform="translate(1250 1200)"><path d="M-140 0 Q0 -60 140 0 Q0 60 -140 0 Z" fill="#fff" opacity={0.9} /></g>
        </g>
      );
    case 'sky':
      return (
        <g>
          <rect x={X0} y={-400} width={W} height={2800} fill="#0B0A26" />
          {[...Array(70)].map((_, i) => <circle key={i} cx={X0 + ((i * 331) % W)} cy={(i * 173) % 1900} r={2 + (i % 3)} fill="#fff" opacity={0.3 + 0.6 * Math.abs(Math.sin(frame / 12 + i))} />)}
          <circle cx={540} cy={560} r={110} fill="#FFB020" stroke="#FFE14D" strokeWidth={10} />
          {[[240, '#C2410C', 34], [360, '#7FD6F2', 26], [480, '#E8B23A', 44]].map(([r, c, s], i) => (
            <g key={i}><circle cx={540} cy={560} r={r as number} fill="none" stroke="#ffffff33" strokeWidth={3} />
              <circle cx={540 + Math.cos(frame / (40 + i * 25) + i) * (r as number)} cy={560 + Math.sin(frame / (40 + i * 25) + i) * (r as number)} r={s as number} fill={c as string} stroke={INK} strokeWidth={5} /></g>
          ))}
          <rect x={X0} y={1150} width={W} height={1300} fill="#1E1650" />
          <ellipse cx={540} cy={1160} rx={1300} ry={60} fill="#2B2270" />
        </g>
      );
    case 'market':
      return (
        <g>
          <Sky top="#FFB25E" mid="#FFE0A3" bot="#FFF1C9" id="msky" />
          {[...Array(7)].map((_, i) => <g key={i} transform={`translate(${-560 + i * 380} 1130)`}>
            <rect x={-150} y={-260} width={300} height={260} fill={['#C2410C', '#0E7490', '#7E22CE', '#2E7D5B'][i % 4]} opacity={0.75} stroke={INK} strokeWidth={4} />
            <path d="M-170 -260 L0 -340 L170 -260 Z" fill="#E8B23A" stroke={INK} strokeWidth={4} />
          </g>)}
          <Ground c1="#D7A86E" c2="#C8945A" />
          <Walkers frame={frame} colors={['#3E7CB1', '#C2410C', '#7E22CE', '#2E7D5B', '#B91C1C']} y={1230} />
        </g>
      );
    case 'village':
    default:
      return (
        <g>
          <Sky top="#FF9E4A" mid="#FFD48A" bot="#FFE9B8" id="vsky" />
          <circle cx={820} cy={380} r={90} fill="#FFF2B0" opacity={0.9} />
          <Gopuram x={560} y={1120} s={1} />
          <Palm x={80} y={1150} s={1} frame={frame} /><Palm x={990} y={1180} s={0.9} frame={frame} /><Palm x={-380} y={1170} s={0.85} frame={frame} /><Palm x={1450} y={1160} s={1} frame={frame} />
          <Ground c1="#D7A86E" c2="#C8945A" />
          <Walkers frame={frame} colors={['#3E7CB1', '#C2410C', '#7E22CE']} y={1230} />
        </g>
      );
  }
};
