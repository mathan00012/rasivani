// Three thumbnail layouts. Text: wrap the personal word in *stars* (உங்க / మీ / YOUR) -> it turns red (cyan on red layouts).
import React from 'react';
import {AbsoluteFill, staticFile, useVideoConfig} from 'remotion';
import {Vani, Local, INK, POSE, LocalKind, Look} from './Toon';
import {Background} from './Scenes';
import {fontCss} from './Episode';

export type ThumbProps = {variant: number; text: string; scene: string; local?: string; look?: Look};

const Words: React.FC<{text: string; size: number; base: string; accent: string; stroke: string}> = ({text, size, base, accent, stroke}) => (
  <>
    {text.split(/(\*[^*]+\*)/).filter(Boolean).map((part, i) => {
      const hot = part.startsWith('*');
      return <span key={i} style={{color: hot ? accent : base, fontSize: hot ? size * 1.18 : size, WebkitTextStroke: `${size * 0.16}px ${stroke}`, paintOrder: 'stroke fill'}}>{hot ? part.slice(1, -1) : part}</span>;
    })}
  </>
);

export const Thumb: React.FC<ThumbProps> = ({variant, text, scene, local = 'THATHA', look = 'classic'}) => {
  const {width, height} = useVideoConfig();
  const long = width > height;
  const v = variant % 3;
  const bgFill = v === 1 ? '#FF1E3C' : v === 2 ? '#FFC93C' : null;
  const accent = v === 1 ? '#00E5FF' : '#FF1E3C';
  const size = long ? 118 : 150;
  // character framing (world coords, feet at y)
  const cam = long ? {s: 0.9, x: 0, y: 0} : {s: 1.25, x: 0, y: 0};
  return (
    <AbsoluteFill style={{background: bgFill || '#120C33', overflow: 'hidden'}}>
      <style>{fontCss(staticFile)}</style>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
        {!bgFill && <g transform={long ? `translate(${width / 2} ${height / 2}) scale(0.75) translate(-540 -1000)` : `scale(1.1) translate(-50 -100)`}><Background name={scene} frame={30} /></g>}
        {bgFill && <g opacity={0.25}>{[...Array(14)].map((_, i) => <path key={i} d={`M${width / 2} ${height * 0.55} L${width / 2 + Math.cos(i / 14 * Math.PI * 2) * 3000} ${height * 0.55 + Math.sin(i / 14 * Math.PI * 2) * 3000} L${width / 2 + Math.cos((i + 0.5) / 14 * Math.PI * 2) * 3000} ${height * 0.55 + Math.sin((i + 0.5) / 14 * Math.PI * 2) * 3000} Z`} fill="#fff" />)}</g>}
        {v === 0 && (
          <g transform={long ? `translate(${width * 0.76} ${height + 520}) scale(${cam.s * 1.35})` : `translate(${width * 0.5} ${height + 380}) scale(${cam.s * 1.6})`}>
            <Vani frame={0} talk={0} expr="shock" armR={POSE.mic} armL={POSE.stop} prop="mic" look={look} lookX={-0.3} />
          </g>
        )}
        {v === 1 && (
          <>
            <g transform={long ? `translate(${width * 0.2} ${height + 470}) scale(1.25)` : `translate(${width * 0.26} ${height + 220}) scale(1.35)`}>
              <Local kind={local as LocalKind} frame={0} talk={0} expr="smirk" armR={POSE.point} lookX={1} />
            </g>
            <g transform={long ? `translate(${width * 0.8} ${height + 500}) scale(1.25)` : `translate(${width * 0.76} ${height + 250}) scale(1.35)`}>
              <Vani frame={0} talk={0} expr="sheepish" armR={POSE.mic} armL={POSE.facepalm} prop="mic" look={look} lookX={-1} sweat />
            </g>
          </>
        )}
        {v === 2 && (
          <g transform={long ? `translate(${width * 0.72} ${height + 640}) scale(1.6)` : `translate(${width * 0.55} ${height + 420}) scale(1.9)`}>
            <Local kind={local as LocalKind} frame={0} talk={0.9} expr="angry" armR={POSE.stop} lookX={-0.6} />
          </g>
        )}
      </svg>
      <div style={{position: 'absolute', left: long ? 50 : 50, right: long ? (v === 1 ? 50 : width * 0.42) : 50, top: long ? (v === 1 ? 30 : 60) : 140,
        textAlign: long && v !== 1 ? 'left' : 'center', fontFamily: 'BalooTa', fontWeight: 800, lineHeight: 1.05, transform: `rotate(${v === 2 ? -3 : 0}deg)`}}>
        <Words text={text} size={size} base={v === 2 ? INK : '#FFFFFF'} accent={accent} stroke={v === 2 ? '#FFFFFF' : INK} />
      </div>
      {v === 2 && <div style={{position: 'absolute', left: long ? 60 : 60, bottom: long ? 0 : 480, fontFamily: 'BalooTa', fontWeight: 800, fontSize: long ? 160 : 240, color: '#FF1E3C', WebkitTextStroke: `14px ${INK}`, paintOrder: 'stroke fill', transform: 'rotate(-12deg)'}}>?!</div>}
      <div style={{position: 'absolute', bottom: 24, right: 30, fontFamily: 'BalooTa', fontWeight: 800, fontSize: long ? 40 : 52, color: '#fff', WebkitTextStroke: `7px ${INK}`, paintOrder: 'stroke fill'}}>RasiVani</div>
    </AbsoluteFill>
  );
};
