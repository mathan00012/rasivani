// RasiVani Toon Studio: paste a story, click Make, get videos + thumbnails + titles.  Run: node tools/studio-server.mjs  → http://localhost:3210
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {parseStory} from './make.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = Number(process.env.PORT || 3210);
let job = {running: false, log: [], slug: null};

const TYPES = {'.mp4': 'video/mp4', '.png': 'image/png', '.txt': 'text/plain; charset=utf-8', '.srt': 'text/plain; charset=utf-8', '.json': 'application/json', '.html': 'text/html; charset=utf-8'};

function listOutputs() {
  const out = path.join(ROOT, 'out');
  if (!fs.existsSync(out)) return [];
  return fs.readdirSync(out).filter((d) => fs.statSync(path.join(out, d)).isDirectory())
    .map((slug) => ({slug, mtime: fs.statSync(path.join(out, slug)).mtimeMs,
      langs: fs.readdirSync(path.join(out, slug)).filter((l) => fs.statSync(path.join(out, slug, l)).isDirectory())
        .map((lang) => ({lang, files: fs.readdirSync(path.join(out, slug, lang))}))}))
    .sort((a, b) => b.mtime - a.mtime);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/') { res.writeHead(200, {'Content-Type': TYPES['.html']}); return res.end(fs.readFileSync(path.join(ROOT, 'tools/studio.html'))); }
  if (url.pathname === '/sample') { res.writeHead(200, {'Content-Type': TYPES['.txt']}); return res.end(fs.readFileSync(path.join(ROOT, 'stories/rahu-kalam.txt'))); }
  if (url.pathname === '/stories') {
    const d = path.join(ROOT, 'stories');
    res.writeHead(200, {'Content-Type': 'application/json'});
    return res.end(JSON.stringify(fs.readdirSync(d).filter((f) => f.endsWith('.txt'))));
  }
  if (url.pathname.startsWith('/story/')) {
    const f = path.join(ROOT, 'stories', path.basename(url.pathname));
    if (!fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    res.writeHead(200, {'Content-Type': TYPES['.txt']}); return res.end(fs.readFileSync(f));
  }
  if (url.pathname === '/outputs') { res.writeHead(200, {'Content-Type': 'application/json'}); return res.end(JSON.stringify(listOutputs())); }
  if (url.pathname === '/status') { res.writeHead(200, {'Content-Type': 'application/json'}); return res.end(JSON.stringify({running: job.running, slug: job.slug, log: job.log.slice(-60)})); }
  if (url.pathname === '/make' && req.method === 'POST') {
    if (job.running) { res.writeHead(409); return res.end('busy'); }
    let body = ''; for await (const c of req) body += c;
    const {text, langs, format} = JSON.parse(body);
    const st = parseStory(text);
    const slug = st.meta.slug.replace(/[^a-z0-9-]/gi, '-').toLowerCase();
    const file = path.join(ROOT, 'stories', `${slug}.txt`);
    fs.mkdirSync(path.dirname(file), {recursive: true});
    fs.writeFileSync(file, text);
    job = {running: true, log: [`Saved stories/${slug}.txt`], slug};
    const p = spawn(process.execPath, [path.join(ROOT, 'tools/make.mjs'), file, '--langs', langs.join(','), '--format', format], {cwd: ROOT, env: process.env});
    const add = (d) => { for (const l of String(d).split(/\r?\n/)) if (l.trim() && !/ExperimentalWarning|trace-warnings/.test(l)) job.log.push(l); };
    p.stdout.on('data', add); p.stderr.on('data', add);
    p.on('close', (code) => { job.running = false; job.log.push(code === 0 ? '✅ Finished' : `❌ Stopped (code ${code})`); });
    res.writeHead(200); return res.end('ok');
  }
  if (url.pathname.startsWith('/out/')) {
    const f = path.join(ROOT, decodeURIComponent(url.pathname));
    if (!f.startsWith(path.join(ROOT, 'out')) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
    const stat = fs.statSync(f), type = TYPES[path.extname(f)] || 'application/octet-stream';
    const range = req.headers.range;
    if (range && type === 'video/mp4') {
      const [s, e] = range.replace('bytes=', '').split('-'); const start = +s, end = e ? +e : stat.size - 1;
      res.writeHead(206, {'Content-Range': `bytes ${start}-${end}/${stat.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Content-Type': type});
      return fs.createReadStream(f, {start, end}).pipe(res);
    }
    res.writeHead(200, {'Content-Type': type, 'Content-Length': stat.size});
    return fs.createReadStream(f).pipe(res);
  }
  res.writeHead(404); res.end();
});
server.listen(PORT, () => console.log(`RasiVani Toon Studio → http://localhost:${PORT}`));
