@echo off
cd /d %~dp0
if not exist node_modules (
  echo First time: installing, takes a few minutes...
  call npm install
)
start "" http://localhost:3210
node tools\studio-server.mjs
