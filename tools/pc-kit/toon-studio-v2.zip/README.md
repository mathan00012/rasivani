# RasiVani Toon Studio

Paste a story, click **Make videos**, get for each language:
video-short.mp4 (9:16 Shorts) and/or video-long.mp4 (16:9 YouTube), 3 thumbnails each, 3 titles, description (with site link, chapters, hashtags) and captions .srt for YouTube upload.
Everything is drawn in code: no images to buy, no GPU. Voices: Sarvam (key read from D:\MADDY\rasivani\KEYS\sarvam).

## Start (Windows)
Double-click START-STUDIO.bat. First time it runs `npm install` (needs Node, which you have).
Your browser opens http://localhost:3210. Outputs are saved in out\<story>\<language>\.
A 1-minute video takes roughly 3-6 minutes on your PC (no graphics card needed). Close other apps while it renders.

## Story format (see stories\rahu-kalam.txt and stories\birth-star.txt)
    SLUG: birth-star            -> file names + site link rasivani.com/learn/<lang>/<slug>/
    FORMAT: short | long | both
    LOOK: classic | saree | langavoni | modern       (VANI's outfit)
    HOOK / CTA / DESC / TAGS:  ta: ... | te: ... | en: ...
    THUMB: x3 and TITLE: x3     (wrap the personal word in *stars*)
    SCENE: studio | village | temple | palace | home | sky | market
    VANI (happy, wave) [react: shock]: ta: ... | te: ... | en: ...
    CARD: Title ; row 1 ; row 2     (info card shown on the next line)
Characters: VANI, THATHA, PAATI, KUTTI, RAJA, VENDOR, PANDIT.
Feelings: happy, shock, smirk, confused, angry, sheepish, think, sad, stern, neutral.
Moves: wave, cheer, point, shrug, think, facepalm, stop, hip, mic, phone.
Up to ~2 minutes per story (about 25-30 lines).

## Command line
    node tools/make.mjs stories/birth-star.txt --langs ta,te,en --format both
    npx remotion studio src/index.ts      (preview / tweak characters live)

Voices per character and language: tools/voices.json.
